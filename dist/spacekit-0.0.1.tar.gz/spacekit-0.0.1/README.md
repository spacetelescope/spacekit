# spacekit
Python package for astronomical machine learning and data science

spacekit
├── LICENSE
├── README.md
├── spacekit_pkg
│   └── __init__.py
├── setup.py
└── tests
